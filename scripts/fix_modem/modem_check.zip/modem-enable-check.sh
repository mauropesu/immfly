#!/bin/bash
# modem-enable-check.sh
# Robust modem auto-enable: detects modem index dynamically,
# handles absence gracefully, safe to run every 2 minutes via timer.

LOG_TAG="modem-enable-check"

# Find the modem index dynamically
MODEM_PATH=$(mmcli -L 2>/dev/null | grep -o '/org/freedesktop/ModemManager1/Modem/[0-9]*' | head -1)

if [ -z "$MODEM_PATH" ]; then
    logger -t "$LOG_TAG" "No modem detected — skipping."
    exit 0
fi

MODEM_INDEX=$(basename "$MODEM_PATH")
STATE=$(mmcli -m "$MODEM_INDEX" 2>/dev/null | grep "state:" | awk '{print $NF}')

logger -t "$LOG_TAG" "Modem $MODEM_INDEX state: $STATE"

case "$STATE" in
    disabled|enabling)
        logger -t "$LOG_TAG" "Modem $MODEM_INDEX is $STATE — enabling..."
        mmcli -m "$MODEM_INDEX" --enable
        logger -t "$LOG_TAG" "Enable command sent to modem $MODEM_INDEX."
        ;;
    enabled|registered|connecting|connected|searching)
        logger -t "$LOG_TAG" "Modem $MODEM_INDEX is already active ($STATE) — nothing to do."
        ;;
    failed)
        logger -t "$LOG_TAG" "Modem $MODEM_INDEX is in failed state — attempting reset..."
        mmcli -m "$MODEM_INDEX" --reset
        ;;
    *)
        logger -t "$LOG_TAG" "Modem $MODEM_INDEX in unhandled state '$STATE' — skipping."
        ;;
esac

exit 0
